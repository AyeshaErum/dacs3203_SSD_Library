// UserLogin.java
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserLogin {

    private Stage stage;
    private Scene loginScene;
    private Scene signUpScene;
    private Scene changePasswordScene; // unused here; created when needed

    // Login controls
    private TextField usernameField = new TextField();
    private PasswordField passwordField = new PasswordField();
    private Label loginMessage = new Label();

    public UserLogin() {
        // default
    }

    public UserLogin(Stage stage) {
        this.stage = stage;
    }

    public void initializeComponents() {
        if (stage == null) {
            throw new IllegalStateException("Stage not set. Create UserLogin with new UserLogin(stage).");
        }

        // Build login scene
        VBox root = new VBox(10);
        root.setPadding(new Insets(12));

        usernameField.setPromptText("username");
        passwordField.setPromptText("password");

        Button loginBtn = new Button("Sign In");
        loginBtn.setOnAction(e -> authenticate());

        // "or" label + Sign Up button (requirement)
        HBox orBox = new HBox(8);
        Label orLabel = new Label("or");
        Button signUpBtn = new Button("Sign up");
        signUpBtn.setOnAction(e -> showSignUpScene());
        orBox.getChildren().addAll(orLabel, signUpBtn);

        root.getChildren().addAll(new Label("Username:"), usernameField,
                new Label("Password:"), passwordField,
                loginBtn, orBox, loginMessage);

        loginScene = new Scene(root, 360, 260);
        stage.setTitle("User Login");
        stage.setScene(loginScene);
        stage.show();
    }

    private void authenticate() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            loginMessage.setText("Please enter username and password.");
            return;
        }

        String sql = "SELECT 1 FROM users WHERE username = ? AND password = ?";
        try (Connection conn = DBUtils.establishConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            pstmt.setString(2, password);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    // success — go to change password scene for this user
                    UserChangePassword cp = new UserChangePassword(stage, username);
                    cp.initializeComponents();
                } else {
                    loginMessage.setText("Invalid username/password.");
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            loginMessage.setText("Database error. Check console.");
        }
    }

    private void showSignUpScene() {
        // Fields for sign-up
        TextField newUsername = new TextField();
        PasswordField newPassword = new PasswordField();
        TextField newRole = new TextField();
        TextField newFirst = new TextField();
        TextField newLast = new TextField();
        Label status = new Label();

        newUsername.setPromptText("username");
        newPassword.setPromptText("password");
        newRole.setPromptText("role");
        newFirst.setPromptText("first name");
        newLast.setPromptText("last name");

        Button createBtn = new Button("Create Account");
        Button backToLogin = new Button("Back to Login");

        createBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String u = newUsername.getText().trim();
                String p = newPassword.getText();
                String r = newRole.getText().trim();
                String fn = newFirst.getText().trim();
                String ln = newLast.getText().trim();

                if (u.isEmpty() || p.isEmpty()) {
                    status.setText("Username and password required.");
                    return;
                }

                // Use prepared statement to avoid SQL injection
                String sql = "INSERT INTO users (username, password, role, firstname, lastname) VALUES (?, ?, ?, ?, ?)";
                try (Connection conn = DBUtils.establishConnection();
                     PreparedStatement pstmt = conn.prepareStatement(sql)) {

                    pstmt.setString(1, u);
                    pstmt.setString(2, p);
                    pstmt.setString(3, r);
                    pstmt.setString(4, fn);
                    pstmt.setString(5, ln);

                    int rows = pstmt.executeUpdate();
                    if (rows > 0) {
                        status.setText("User created. Redirecting to Change Password...");
                        // automatically go to change password scene for new user
                        UserChangePassword cp = new UserChangePassword(stage, u);
                        cp.initializeComponents();
                    } else {
                        status.setText("Failed to create user.");
                    }

                } catch (java.sql.SQLIntegrityConstraintViolationException e) {
                    // duplicate username
                    status.setText("Username already exists. Choose another.");
                } catch (Exception ex) {
                    ex.printStackTrace();
                    status.setText("Database error. Check console.");
                }
            }
        });

        backToLogin.setOnAction(e -> {
            // Reset login fields if needed
            usernameField.clear();
            passwordField.clear();
            loginMessage.setText("");
            stage.setScene(loginScene);
        });

        VBox layout = new VBox(8,
                new Label("Create new user"),
                new Label("Username:"), newUsername,
                new Label("Password:"), newPassword,
                new Label("Role:"), newRole,
                new Label("First Name:"), newFirst,
                new Label("Last Name:"), newLast,
                createBtn, backToLogin, status
        );
        layout.setPadding(new Insets(12));

        signUpScene = new Scene(layout, 380, 480);
        stage.setScene(signUpScene);
        stage.setTitle("Sign Up");
        stage.show();
    }
}
